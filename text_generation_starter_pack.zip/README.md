# Starter pack for automatic text generation

## Files
- `text_atoms_schema.json` — JSON schema for the content atoms library
- `text_atoms_starter.json` — starter content atoms and example rules
- `codex_prompt_text_generation.md` — prompt for Codex to implement the generator

## Generation model
Pipeline:
1. calculations
2. interpretationKeys/contentSignals
3. rule engine
4. text composer
5. final UI sections

## Recommended output per section
- `sectionCode`
- `title`
- `previewText`
- `fullText`
- `teaser`
- `usedRules`
- `usedSignals`
- `isLocked`

## Composition order
1. intro
2. strengths
3. shadow
4. manifestation
5. signal inserts / warnings / advice
6. advice
7. teaser

## Free/Paid
- Free: return 25–35% of text as `previewText`
- Paid: return full text
- Locked sections should always have teaser + CTA in UI

## Important
Do not generate text directly in UI.
Make the system deterministic and testable first.