Нужно реализовать автоматическую генерацию текстов для матрицы на основе rule-engine и text atoms library.

## Используй файлы
- text_atoms_schema.json
- text_atoms_starter.json

## Цель
Заменить короткие шаблонные тексты на composable generation.

## Архитектура
Сделай pipeline:
1. calculations
2. interpretationKeys
3. contentSignals
4. rule engine
5. text composer
6. final content sections for UI

## Нужно реализовать

### 1. Data model
Подключи starter JSON как content source.
Поддержи contexts:
- personality
- talents
- money
- love
- mission
- karma
- health
- forecast

### 2. Rule engine
Rule engine должен:
- читать rules из JSON
- матчить по interpretationKeys/contentSignals
- собирать signal atoms
- поддерживать prepend/append signal inserts
- поддерживать warnings/advice/teasers

### 3. Composer
Composer должен:
- выбирать базовые atoms по primary energy и context
- добавлять signal atoms
- собирать text в порядке:
  intro -> strengths -> shadow -> manifestation -> inserts/warnings -> advice -> teaser
- возвращать:
  - title
  - previewText
  - fullText
  - teaser
  - usedRules
  - usedSignals
  - isLocked

### 4. Free/Paid logic
- free mode: previewText = первые 25–35% полного текста + teaser
- paid mode: fullText полностью
- locked sections не должны раскрывать весь текст бесплатно

### 5. Example support
Сначала поддержи на рабочем уровне примеры из starter JSON:
- energy 1
- energy 6
- energy 15
- energy 20
- signal atoms:
  - strongLeadership
  - relationshipInstability
  - emotionalOverload
  - strongMaterialPotential

### 6. Important constraints
- не генерировать тексты прямо в React components
- не ломать provider architecture
- не ломать unified result contract
- сделать систему тестируемой
- UI должен только рендерить уже готовые секции

## Сначала покажи
1. data model wiring
2. rule engine design
3. composer design
4. example outputs for 2 users

Потом внедри.